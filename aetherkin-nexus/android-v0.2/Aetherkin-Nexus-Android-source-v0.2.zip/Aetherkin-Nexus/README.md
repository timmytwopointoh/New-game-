# Aetherkin Nexus — Android v0.2.0 source alpha

**Target: an offline, standalone Android phone game** inspired by the general explore → capture → transform → arena idea. It is NOT a PC game controlled by an Android phone. The PC is used only to develop, compile and test the APK. This is an original project, unrelated to licensed Chaotic intellectual property.

## Implemented in source (not yet device verified)
- 360 uniquely named creature entries, 12 primitive procedural anatomy families, 6 elements and 5 strains, JSON data and local collection persistence.
- Portal hub, four creature exploration realms, arena, creature AI, damage, weakened-creature capture, transformation, colored effects and basic skeletal-style procedural movement blockouts.
- Android landscape touchscreen: joystick, swipe-to-look, STRIKE, SPECIAL, CAPTURE/ENTER, DASH, JUMP, TRANSFORM, NEXT FORM and CODEX.
- Scrollable collection list with choose-form / become selected / close buttons, instead of first-18-only desktop Codex.
- Mobile performance starter profile: max 45 FPS, 9 roaming enemies per realm / 6 arena enemies, shadow disabled on mobile, transient effects capped.
- Dedicated `com.veilforge.aetherkinnexus` package, Android ARM64 + x86_64 emulator export presets, local icon, source QA and gated Windows PowerShell QA script.

## Android build prerequisites
- A compatible official Godot 4 editor and **matching official Android export templates**, an approved Android SDK/ADB, and the Godot-required JDK installed on the Windows PC. The source authoring runtime did not have a Godot editor or Android exporter.
- Open `project.godot`. `export_presets.cfg` has `Android Phone ARM64` and `Android Emulator x86_64` (separate test APK variants). Debug test signing should use the PC's existing Godot debug-keystore configuration. Do not publish keys or keystore passwords.
- To test, the approved PC parent can inspect then invoke `pc/verify-android-test.ps1` with explicit approved project/Godot/ADB paths. No new dependencies, permissions or device setup is attempted by the script.
- Offline data saved inside Android app storage at `user://aetherkin_save_v1.json`. **Uninstalling clears the save**, so every update must keep this package ID and signing identity and use in-place install. Release signing has not been established yet.

## Controls
- Phone: left thumb joystick to move; drag unoccupied right/middle screen to look; dedicated on-screen action buttons; CODEX lists the entire captured inventory.
- PC testing: WASD/mouse, Space jump, Shift dash, E capture/portal, J/click strike, Q special, T transform, C cycle, Tab Codex, Esc release mouse, F5 save.
- Dev-only PC touch preview: change `aetherkin/force_touch_controls=true` in `project.godot` or via editor; never ship forced touch on Windows.

## Verify source
`python tools/test_catalog.py` and `python tools/test_android.py` run deterministic, offline source checks only.
See `docs/ANDROID_TEST_PLAN.md` for emulator / APK acceptance gates. A static test pass does **not** mean the game launches on Android.

## Not done yet
No APK has been built or installed by this source creation process; no headless Godot compile/emulator playtest has been performed. Creature meshes and animations are temporary procedural blockouts, **not** final top-notch anime assets. Networking/multiplayer is for a later phase. Preserve existing VEILFORGE Studio, VQ, Peks, Minecraft and Sector repositories without changes.
