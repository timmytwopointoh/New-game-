extends Node3D
## Self-contained procedural map generation; no external art or services.

const ZONE_NAMES = {
    "hub": "Nexus Citadel", "verdant": "Viridian Wilds",
    "ember": "Ashfall Crater", "frost": "Glacier Crown",
    "volt": "Tempest Mesa", "arena": "Ascension Arena"
}
const ZONE_COLORS = {
    "hub": "#344B72", "verdant": "#286858", "ember": "#673F41",
    "frost": "#5B9DBD", "volt": "#63529A", "arena": "#343651"
}
var portals: Array = []
var active_zone := "hub"
var zone_root: Node3D
var rng := RandomNumberGenerator.new()

func build(zone: String) -> void:
    if is_instance_valid(zone_root):
        zone_root.queue_free()
    zone_root = Node3D.new()
    add_child(zone_root)
    active_zone = zone
    portals.clear()
    rng.seed = int(zone.hash()) & 0x7fffffff
    var base := Color.html(str(ZONE_COLORS.get(zone, ZONE_COLORS["hub"])))
    _block(Vector3(0, -0.46, 0), Vector3(92, 0.90, 92), base, true)
    _block(Vector3(0, -0.015, 0), Vector3(92, 0.03, 92), base.lightened(0.14))
    if zone == "hub":
        _build_hub()
    elif zone == "arena":
        _build_arena()
    else:
        _build_wilderness(zone)

func _build_hub() -> void:
    _block(Vector3(0, 0.15, 1), Vector3(24, 0.3, 24), Color("#33435B"))
    _cylinder(Vector3(0, 0.28, 1), Vector3(5.2, 0.40, 5.2), Color("#7D739D"))
    _cylinder(Vector3(0, 0.55, 1), Vector3(3.5, 0.06, 3.5), Color("#3DC5DE"), true)
    for n in range(12):
        var angle := TAU * float(n) / 12.0
        var radius := 22.0
        var pt := Vector3(sin(angle) * radius, 0, cos(angle) * radius)
        _tower(pt, Color("#8995C2"))
    _gateway(Vector3(-15, 0, -11), "Viridian Wilds", "verdant", Color("#58ED92"))
    _gateway(Vector3(-7, 0, -20), "Ashfall Crater", "ember", Color("#FF754D"))
    _gateway(Vector3(7, 0, -20), "Glacier Crown", "frost", Color("#9EDFFF"))
    _gateway(Vector3(15, 0, -11), "Tempest Mesa", "volt", Color("#BBA6FF"))
    _gateway(Vector3(0, 0, 18), "Ascension Arena", "arena", Color("#FFD46E"))
    _sign(Vector3(0, 4.5, -1.2), "AETHERKIN NEXUS", Color("#FFF3D6"), 42)
    _sign(Vector3(0, 3.5, -1.2), "Discover  •  Capture  •  Become", Color("#D2E5FF"), 22)
    for n in range(32):
        var a := rng.randf_range(0.0, TAU)
        var d := rng.randf_range(28.0, 39.0)
        _crystal(Vector3(sin(a)*d, 0, cos(a)*d), Color("#94B2FF"))

func _build_arena() -> void:
    _cylinder(Vector3(0, 0.08, 0), Vector3(16.5, 0.17, 16.5), Color("#7A6C9C"))
    _cylinder(Vector3(0, 0.18, 0), Vector3(15.7, 0.1, 15.7), Color("#34334F"))
    _cylinder(Vector3(0, 0.27, 0), Vector3(11.5, 0.03, 11.5), Color("#3B7188"), true)
    for n in range(28):
        var a := float(n) * TAU / 28.0
        var r := 19.0
        _tower(Vector3(cos(a)*r, 0, sin(a)*r), Color("#5F648C"))
    _gateway(Vector3(0, 0, 27), "Nexus Citadel", "hub", Color("#79DEF4"))
    _sign(Vector3(0, 6.0, -20), "ASCENSION ARENA", Color("#FFD889"), 37)

func _build_wilderness(zone: String) -> void:
    _gateway(Vector3(0, 0, 26), "Nexus Citadel", "hub", Color("#7BDFEE"))
    for n in range(74):
        var x := rng.randf_range(-41, 41)
        var z := rng.randf_range(-39, 39)
        if Vector2(x, z).length() < 8.0 or Vector2(x, z - 26).length() < 7.5:
            continue
        var place := Vector3(x, 0, z)
        if zone == "verdant":
            _tree(place, Color("#35BA6C") if n % 3 else Color("#70C7AA"))
        elif zone == "ember":
            _crystal(place, Color("#FF6F43") if n % 3 else Color("#FFCF65"))
            if n % 7 == 0:
                _block(place + Vector3(0, 0.24, 0), Vector3(1.8, 0.45, 1.8), Color("#34303A"))
        elif zone == "frost":
            _crystal(place, Color("#83D8FF") if n % 3 else Color("#BCEEFF"))
        elif zone == "volt":
            if n % 3 == 0:
                _tree(place, Color("#8A70DC"))
            else:
                _crystal(place, Color("#AF95FF"))
    _sign(Vector3(0, 4.4, -26), str(ZONE_NAMES[zone]).to_upper(), Color("#FFFFFF"), 36)

func _tree(pos: Vector3, leaves: Color) -> void:
    var height := rng.randf_range(2.5, 5.7)
    _cylinder(pos + Vector3(0, height * 0.45, 0), Vector3(0.25, height * 0.9, 0.25), Color("#664E57"))
    _sphere(pos + Vector3(0, height, 0), Vector3(1.2, 1.6, 1.2), leaves)
    _sphere(pos + Vector3(0.58, height * 0.88, 0), Vector3(0.68, 1.0, 0.7), leaves.lightened(0.16))

func _crystal(pos: Vector3, color: Color) -> void:
    var height := rng.randf_range(1.6, 4.1)
    _cylinder(pos + Vector3(0, height * 0.5, 0), Vector3(0.44, height, 0.44), color, true, 6)
    _sphere(pos + Vector3(0, height * 1.04, 0), Vector3(0.35, 0.55, 0.35), color.lightened(0.35))

func _tower(pos: Vector3, color: Color) -> void:
    _cylinder(pos + Vector3(0, 2.1, 0), Vector3(1.25, 4.2, 1.25), color, false, 8)
    _cylinder(pos + Vector3(0, 4.25, 0), Vector3(1.75, 0.3, 1.75), color.lightened(0.17), false, 8)
    _sphere(pos + Vector3(0, 5.05, 0), Vector3(0.65, 0.98, 0.65), Color("#65E2F0"), true)

func _gateway(pos: Vector3, name: String, destination: String, color: Color) -> void:
    var ring := MeshInstance3D.new()
    var mesh := TorusMesh.new()
    mesh.inner_radius = 1.32
    mesh.outer_radius = 1.58
    ring.mesh = mesh
    ring.rotation_degrees.x = 90
    ring.position = pos + Vector3(0, 2.2, 0)
    ring.material_override = _mat(color, true)
    zone_root.add_child(ring)
    _sphere(pos + Vector3(0, 2.2, 0), Vector3(1.24, 1.70, 0.12), color.darkened(0.48), true)
    _sign(pos + Vector3(0, 4.8, 0), name, color.lightened(0.32), 24)
    portals.append({"position": pos, "name": name, "target": destination})

func _sign(pos: Vector3, words: String, color: Color, size: int = 25) -> void:
    var label := Label3D.new()
    label.text = words
    label.font_size = size
    label.pixel_size = 0.010
    label.modulate = color
    label.outline_size = 8
    label.position = pos
    zone_root.add_child(label)

func _block(pos: Vector3, dims: Vector3, color: Color, solid: bool = false) -> void:
    var m := BoxMesh.new()
    m.size = dims
    var mesh := MeshInstance3D.new()
    mesh.mesh = m
    mesh.material_override = _mat(color)
    mesh.position = pos
    zone_root.add_child(mesh)
    if solid:
        var body := StaticBody3D.new()
        var coll := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = dims
        coll.shape = shape
        body.position = pos
        body.add_child(coll)
        zone_root.add_child(body)

func _sphere(pos: Vector3, dims: Vector3, color: Color, glow: bool = false) -> void:
    var m := SphereMesh.new()
    m.radial_segments = 12
    m.rings = 6
    var mesh := MeshInstance3D.new()
    mesh.mesh = m
    mesh.material_override = _mat(color, glow)
    mesh.position = pos
    mesh.scale = dims
    zone_root.add_child(mesh)

func _cylinder(pos: Vector3, dims: Vector3, color: Color, glow: bool = false, sides: int = 14) -> void:
    var m := CylinderMesh.new()
    m.top_radius = 0.50
    m.bottom_radius = 0.50
    m.height = 1.0
    m.radial_segments = sides
    var mesh := MeshInstance3D.new()
    mesh.mesh = m
    mesh.material_override = _mat(color, glow)
    mesh.position = pos
    mesh.scale = dims
    zone_root.add_child(mesh)

func _mat(color: Color, glow: bool = false) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.82
    if glow:
        m.emission_enabled = true
        m.emission = color
        m.emission_energy_multiplier = 1.9
    return m
