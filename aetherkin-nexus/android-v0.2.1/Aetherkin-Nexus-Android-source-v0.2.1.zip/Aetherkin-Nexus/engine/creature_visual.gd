extends Node3D
## One procedural presentation system shared by all 360 playable catalog entries.
## This is a blockout rig, NOT the final hand-keyed/retargeted anime animation.

const TOON = preload("res://shaders/toon.gdshader")
var family := "Guardian"
var root_body: Node3D
var left_limb: Node3D
var right_limb: Node3D
var left_leg: Node3D
var right_leg: Node3D
var tail_pivot: Node3D
var left_wing: Node3D
var right_wing: Node3D
var phase := 0.0
var body_color := Color(0.5, 0.8, 1.0)
var accent := Color(1.0, 0.8, 0.3)
var visual_scale := 1.0

func set_creature(spec: Dictionary) -> void:
    family = str(spec.get("family", "Guardian"))
    body_color = Color.html(str(spec.get("color", "#55D4E3")))
    accent = body_color.lightened(0.36)
    visual_scale = 0.88 + float(int(spec.get("variant_seed", 1)) % 7) * 0.055
    for child in get_children():
        child.queue_free()
    root_body = Node3D.new()
    add_child(root_body)
    scale = Vector3.ONE * visual_scale
    _sculpt()

func _sculpt() -> void:
    var main_height := 1.7
    var main_width := 0.66
    if family in ["Golem", "Guardian", "Chimera"]:
        main_height = 2.15
        main_width = 0.90
    elif family in ["Sprite", "Wisp", "Scarab"]:
        main_height = 1.3
        main_width = 0.54
    elif family in ["Serpent", "Wyvern"]:
        main_height = 1.9
    _orb(root_body, Vector3(0, main_height * 0.65, 0), Vector3(main_width, main_height * 0.56, main_width * 0.70), body_color)
    _orb(root_body, Vector3(0, main_height + 0.32, 0), Vector3(main_width * 0.59, 0.51, main_width * 0.56), accent)
    _orb(root_body, Vector3(-0.19, main_height + 0.40, -0.41), Vector3(0.085, 0.14, 0.07), Color(0.06, 0.12, 0.22), true)
    _orb(root_body, Vector3(0.19, main_height + 0.40, -0.41), Vector3(0.085, 0.14, 0.07), Color(0.06, 0.12, 0.22), true)
    if family in ["Wyvern", "Chimera", "Guardian", "Lynx", "Stag"]:
        _cone(root_body, Vector3(-0.35, main_height + 0.75, 0), Vector3(0.18, 0.70, 0.18), accent)
        _cone(root_body, Vector3(0.35, main_height + 0.75, 0), Vector3(0.18, 0.70, 0.18), accent)
    if family in ["Mantis", "Scarab", "Raptor"]:
        _cone(root_body, Vector3(0, main_height + 0.80, -0.14), Vector3(0.24, 0.78, 0.24), accent)
    left_limb = Node3D.new()
    right_limb = Node3D.new()
    left_leg = Node3D.new()
    right_leg = Node3D.new()
    root_body.add_child(left_limb)
    root_body.add_child(right_limb)
    root_body.add_child(left_leg)
    root_body.add_child(right_leg)
    left_limb.position = Vector3(-main_width * 0.89, main_height * 0.9, 0)
    right_limb.position = Vector3(main_width * 0.89, main_height * 0.9, 0)
    left_leg.position = Vector3(-main_width * 0.44, main_height * 0.38, 0)
    right_leg.position = Vector3(main_width * 0.44, main_height * 0.38, 0)
    _orb(left_limb, Vector3(-0.20, -0.37, 0), Vector3(0.25, 0.57, 0.25), body_color.darkened(0.2))
    _orb(right_limb, Vector3(0.20, -0.37, 0), Vector3(0.25, 0.57, 0.25), body_color.darkened(0.2))
    _orb(left_leg, Vector3(0, -0.35, 0), Vector3(0.29, 0.54, 0.30), accent.darkened(0.22))
    _orb(right_leg, Vector3(0, -0.35, 0), Vector3(0.29, 0.54, 0.30), accent.darkened(0.22))
    tail_pivot = Node3D.new()
    root_body.add_child(tail_pivot)
    tail_pivot.position = Vector3(0, main_height * 0.48, main_width * 0.8)
    if family in ["Serpent", "Wyvern", "Chimera", "Lynx", "Raptor"]:
        _orb(tail_pivot, Vector3(0, -0.05, 0.6), Vector3(0.22, 0.22, 0.95), body_color)
        _cone(tail_pivot, Vector3(0, 0, 1.43), Vector3(0.29, 0.58, 0.29), accent, Vector3(90, 0, 0))
    if family in ["Wyvern", "Wisp", "Sprite", "Scarab"]:
        left_wing = Node3D.new()
        right_wing = Node3D.new()
        root_body.add_child(left_wing)
        root_body.add_child(right_wing)
        left_wing.position = Vector3(-0.35, main_height * 1.05, 0.25)
        right_wing.position = Vector3(0.35, main_height * 1.05, 0.25)
        _orb(left_wing, Vector3(-0.85, 0.25, 0.1), Vector3(1.0, 0.1, 0.58), accent)
        _orb(right_wing, Vector3(0.85, 0.25, 0.1), Vector3(1.0, 0.1, 0.58), accent)
    if family == "Stag":
        _cone(root_body, Vector3(-0.5, main_height + 1.11, 0.06), Vector3(0.1, 0.84, 0.1), accent)
        _cone(root_body, Vector3(0.5, main_height + 1.11, 0.06), Vector3(0.1, 0.84, 0.1), accent)
    if family == "Golem":
        for side in [-1, 1]:
            _orb(root_body, Vector3(side * 0.88, 1.75, 0), Vector3(0.5, 0.48, 0.57), accent.darkened(0.26))
    if family == "Wisp":
        _orb(root_body, Vector3(0, 0.50, 0), Vector3(0.53, 0.15, 0.53), accent, true)

func advance(delta: float, motion: float, striking: bool) -> void:
    phase += delta * (2.2 + motion * 8.0)
    if root_body == null:
        return
    root_body.position.y = sin(phase * 1.55) * (0.04 + motion * 0.075)
    root_body.rotation.y = sin(phase * 0.68) * 0.055
    var swing := sin(phase) * motion * 0.62
    if is_instance_valid(left_limb):
        left_limb.rotation.x = swing + (1.15 if striking else 0.0)
        right_limb.rotation.x = -swing + (0.6 if striking else 0.0)
    if is_instance_valid(left_leg):
        left_leg.rotation.x = -swing * 0.8
        right_leg.rotation.x = swing * 0.8
    if is_instance_valid(tail_pivot):
        tail_pivot.rotation.y = sin(phase * 1.18) * 0.22
    if is_instance_valid(left_wing):
        left_wing.rotation.z = sin(phase * 3.1) * 0.36 - 0.15
        right_wing.rotation.z = -left_wing.rotation.z

func _orb(parent: Node3D, local_pos: Vector3, form: Vector3, tint: Color, glow: bool = false) -> void:
    var n := MeshInstance3D.new()
    var m := SphereMesh.new()
    m.radial_segments = 16
    m.rings = 8
    n.mesh = m
    n.position = local_pos
    n.scale = form
    n.material_override = _material(tint, glow)
    parent.add_child(n)

func _cone(parent: Node3D, local_pos: Vector3, form: Vector3, tint: Color, angles: Vector3 = Vector3.ZERO) -> void:
    var n := MeshInstance3D.new()
    var m := CylinderMesh.new()
    m.top_radius = 0.0
    m.bottom_radius = 0.5
    m.height = 1.0
    n.mesh = m
    n.position = local_pos
    n.rotation_degrees = angles
    n.scale = form
    n.material_override = _material(tint)
    parent.add_child(n)

func _material(tint: Color, glow: bool = false) -> Material:
    var mat := ShaderMaterial.new()
    mat.shader = TOON
    mat.set_shader_parameter("albedo_tint", tint)
    mat.set_shader_parameter("emission_boost", 0.65 if glow else 0.065)
    return mat
