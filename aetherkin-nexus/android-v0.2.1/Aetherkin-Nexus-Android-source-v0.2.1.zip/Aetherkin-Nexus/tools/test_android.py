#!/usr/bin/env python3
"""Offline Android source checks; these do not simulate Godot or a phone."""
from pathlib import Path
import configparser, re, unittest
ROOT = Path(__file__).resolve().parent.parent
class AndroidContract(unittest.TestCase):
 def test_mobile_scripts_and_actions(self):
  s=(ROOT/'mobile/touch_controls.gd').read_text()
  j=(ROOT/'mobile/joystick.gd').read_text()
  main=(ROOT/'game/main.gd').read_text()
  expected={'ak_attack','ak_skill','ak_use','ak_jump','ak_dash','ak_morph','ak_cycle','ak_collection'}
  actions=set(re.findall(r'"(ak_[a-z_]+)"',s))
  self.assertEqual(expected,actions)
  self.assertIn('InputEventScreenDrag',main)
  self.assertIn('InputEventScreenDrag',j)
  self.assertIn('active_finger',j)
  self.assertIn('mobile_mode',main)
  self.assertIn('touch_ui.movement',main)
 def test_export_presets(self):
  c=configparser.ConfigParser(interpolation=None)
  c.read(ROOT/'export_presets.cfg')
  self.assertEqual(c['preset.0']['platform'].strip('"'),'Android')
  self.assertEqual(c['preset.1']['platform'].strip('"'),'Android')
  self.assertEqual(c['preset.0.options']['package/unique_name'].strip('"'),'com.veilforge.aetherkinnexus')
  self.assertEqual(c['preset.1.options']['package/unique_name'].strip('"'),'com.veilforge.aetherkinnexus')
  self.assertEqual(c['preset.0.options']['architectures/arm64-v8a'],'true')
  self.assertEqual(c['preset.0.options']['architectures/x86_64'],'false')
  self.assertEqual(c['preset.1.options']['architectures/arm64-v8a'],'false')
  self.assertEqual(c['preset.1.options']['architectures/x86_64'],'true')
 def test_mobile_boot_and_codex(self):
  main=(ROOT/'game/main.gd').read_text()
  for term in ['Touch.new()', 'ItemList.new()', 'set_item_metadata', 'get_item_metadata', 'Engine.max_fps = 45', 'sun.shadow_enabled = not mobile_mode']:
   self.assertIn(term,main)
  self.assertTrue((ROOT/'art/icon-192.png').exists())
 def test_no_network_signing_secrets(self):
  for f in ROOT.rglob('*'):
   self.assertNotIn(f.suffix.lower(),{'.keystore','.jks','.p12','.pem'})
  s='\n'.join(x.read_text() for x in ROOT.rglob('*.gd'))
  for bad in ('HTTPRequest.new(', 'WebSocketPeer.new(', 'OS.execute(', 'FileAccess.open_encrypted_with_pass('):
   self.assertNotIn(bad,s)
 def test_pc_android_plan(self):
  text=(ROOT/'pc/verify-android-test.ps1').read_text()
  self.assertIn("'^emulator-[0-9]+$'",text)
  self.assertIn('install -r',text)
  self.assertIn('--export-debug',text)
  self.assertIn('Get-FileHash',text)
if __name__=='__main__': unittest.main(verbosity=2)
