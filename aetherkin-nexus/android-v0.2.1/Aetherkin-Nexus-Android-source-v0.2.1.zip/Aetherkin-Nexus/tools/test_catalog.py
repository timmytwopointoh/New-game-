#!/usr/bin/env python3
import json
import re
import unittest
from pathlib import Path
from generate_catalog import make_catalog, ARCHETYPES, ELEMENTS, STRAINS

ROOT = Path(__file__).resolve().parent.parent

class TestAetherkinCatalog(unittest.TestCase):
    def test_exact_360_unique(self):
        roster = make_catalog()
        self.assertEqual(len(roster), 360)
        self.assertEqual(len({c['id'] for c in roster}), 360)
        self.assertEqual(len({c['name'] for c in roster}), 360)
        self.assertEqual(len({(c['family'], c['element'], c['strain']) for c in roster}), 360)
    def test_generated_file_is_reproducible(self):
        self.assertEqual(json.loads((ROOT/'data/creatures.json').read_text()), make_catalog())
    def test_schema_and_balancing(self):
        for c in make_catalog():
            self.assertIn(c['family'], ARCHETYPES)
            self.assertIn(c['element'], {e[0] for e in ELEMENTS})
            self.assertIn(c['strain'], STRAINS)
            self.assertRegex(c['id'], '^AK[0-9]{3}$')
            self.assertGreater(c['hp'], c['attack'])
            self.assertGreater(c['speed'], 0)
            self.assertTrue(0 < c['capture_difficulty'] < 1)
            self.assertRegex(c['color'], '^#[A-F0-9]{6}$')
    def test_local_resource_paths(self):
        for rel in ['project.godot','scenes/main.tscn','game/main.gd','engine/creature_visual.gd','engine/world_builder.gd','shaders/toon.gdshader']:
            self.assertTrue((ROOT/rel).is_file(), rel)
        for file in ROOT.rglob('*.gd'):
            for resource in re.findall(r'(?:preload|load)\("res://([^" ]+)"\)', file.read_text()):
                self.assertTrue((ROOT/resource).is_file(), f'{file}: {resource}')
    def test_no_network_or_foreign_ip(self):
        for path in list(ROOT.rglob('*.gd')) + list(ROOT.rglob('*.json')):
            if path.name == 'creatures.json':
                continue
            text = path.read_text()
            for banned in ['chaoticgame.com', 'Mipedian', 'Danians', 'Chaotic Code', 'HTTPRequest.new(', 'WebSocketPeer.new(']:
                self.assertNotIn(banned, text, path.name)

if __name__ == '__main__':
    unittest.main(verbosity=2)
