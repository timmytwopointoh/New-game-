#!/usr/bin/env python3
"""Deterministic original fictional 360-form catalog; stdlib only."""
import json
from pathlib import Path

ARCHETYPES = ["Wyvern", "Lynx", "Golem", "Wisp", "Mantis", "Serpent", "Guardian", "Stag", "Raptor", "Scarab", "Chimera", "Sprite"]
ELEMENTS = [
    ("Ember", "#FF6339", "Ignition"),
    ("Tide", "#36B9EC", "Tidal Surge"),
    ("Volt", "#E5D64C", "Arc Rush"),
    ("Verdant", "#56D795", "Briar Bloom"),
    ("Terra", "#CB975F", "Stonebreaker"),
    ("Frost", "#A2D7FF", "Whiteout"),
]
STRAINS = ["Feral", "Valiant", "Prime", "Ancient", "Eclipse"]


def make_catalog():
    result = []
    for family_idx, family in enumerate(ARCHETYPES):
        for element_idx, (element, color, special) in enumerate(ELEMENTS):
            for strain_idx, strain in enumerate(STRAINS):
                index = len(result) + 1
                result.append({
                    "id": "AK%03d" % index,
                    "name": f"{strain} {element} {family}",
                    "family": family,
                    "element": element,
                    "strain": strain,
                    "color": color,
                    "level": 1 + strain_idx * 3 + family_idx // 3,
                    "hp": 80 + family_idx * 9 + strain_idx * 17,
                    "attack": 10 + element_idx * 3 + strain_idx * 4,
                    "speed": round(4.8 + (family_idx % 4) * 0.4 - strain_idx * 0.1, 2),
                    "skill": special,
                    "rarity": ["common", "uncommon", "rare", "epic", "legendary"][strain_idx],
                    "variant_seed": index * 17 + 33,
                    "capture_difficulty": round(0.25 + strain_idx * 0.08, 2),
                })
    assert len(result) == 360 and len(set(s["id"] for s in result)) == 360
    return result


if __name__ == "__main__":
    dest = Path(__file__).resolve().parent.parent / "data" / "creatures.json"
    dest.write_text(json.dumps(make_catalog(), indent=2) + "\n", encoding="utf-8")
    print(f"Generated {len(make_catalog())} original creature definitions -> {dest}")
