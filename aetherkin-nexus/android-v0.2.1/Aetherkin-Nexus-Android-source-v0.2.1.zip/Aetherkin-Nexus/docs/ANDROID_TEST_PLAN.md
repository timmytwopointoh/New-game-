# Aetherkin Nexus — Android v0.2 QA acceptance plan

## Platform and isolation
Target: standalone **Android APK for the user's phone**; landscape touchscreen game, fully local save, no PC runtime dependency. The Windows PC is a source/build/ADB emulator worker only. Original game concept inspired by the broad exploration/capture/transformation/arena structure, without copying the Chaotic franchise or its copyrighted characters, terms or settings.

- Package: `com.veilforge.aetherkinnexus` (dedicated, never reuse Minecraft/Realm or Peks package/signing key).
- Source: Godot 4, GDScript, GL Compatibility renderer for broad mobile reach.
- Android ARM64 debug test preset + x86_64 emulator preset; same source and distinct APK builds.
- The debug APK is **not** a signed production release. A stable, private Aetherkin-specific release signing identity is required before a public/installable long-term update channel is established. Never publish passwords, keystore or signing configuration to GitHub.
- No GitHub Actions, external API, analytics, accounts or network requests.

## Manual, observable test checklist (do not claim merely from export success)
1. Import Godot project headlessly and run a bounded 240-frame startup smoke test; no parser/runtime errors.
2. Export both Android APKs with official matching Godot export templates. Record actual version, architecture, Godot version, size, SHA256, signature information and package ID.
3. With the owner's explicitly authorized `emulator-####` only: `adb install -r` (never uninstall/reset data) and open app. Check for crash, invisible graphics, UI overlap and landscape orientation.
4. Drag LEFT joystick, verify directional movement stops on release and camera turns when dragging free area. Check multitouch: move + strike, move + dash, move + jump, and special.
5. Enter Viridian Wilds using green portal and CAPTURE / ENTER. Defeat/weaken a creature below 42%, capture it, transform and verify its creature movement/attack attributes.
6. Open CODEX. Verify scroll through all owned entries, selection, BECOME SELECTED and CLOSE; verify no movement while Codex open.
7. Return to Nexus through zone portal; enter arena, defeat at least one enemy; verify encounter HP, character animations and the action FX dissipate.
8. Quit and relaunch without clearing data. Confirm captured creature, active form and transformation persist. Verify installing a higher version code with identical signing identity preserves save.
9. Profile actual FPS on entry, heavy combat and Codex for 5 minutes on a representative low/medium emulator and, separately, on user's real phone. Aim at stable 30 FPS minimum on the approved target, with dynamic budgets/LOD as needed. Mobile initial cap is 45 FPS, no dynamic quality yet.
10. If errors, change one bounded cause per iteration, repeat relevant tests and record proof; do not treat scripts/static checks as emulator success. Stop on missing Godot/SDK/templates, unavailable emulator, or conflicting owner PC job.

## Acceptance for user-facing test APK
- Real Godot export, local launch and gameplay, repeatable save/reload, no immediate crashes, visible/on-screen touch controls that work.
- New app ID and stable project-specific certificate verified for in-place updates before declaring test-APK ready for long-term use. If only a debug APK is available, clearly label it an ephemeral emulator test and do not promise seamless upgrades.
- Publish APK and immutable source revision to approved private project release or secured transport; link only after upload is verified and report hash/size/version/package.
- Outstanding: individually art-directed 360 creature models, fully skeletal anime-quality animations, advanced AI, multiplayer, content expansion. These remain milestones, not part of v0.2 acceptance.

## Ordered PC loop
A. Reconcile VF-0024 source workspace bootstrap. Never duplicate or overwrite an existing workspace.
B. Once dedicated repository exists and parent is idle, sync v0.2 source as a separate commit; run catalog tests + Godot import + smoke.
C. Export emulator/phone variants. Test only on explicitly authorized PC emulator. If fail, submit sanitized error stage with precise fix candidate; rerun bound of 3 passes. Do not send raw auth, paths, credentials, private files, other game logs.
D. Once successful, prepare dedicated signed Android test APK and validate direct phone install/update. Publish one link and SHA256 for owner testing.
