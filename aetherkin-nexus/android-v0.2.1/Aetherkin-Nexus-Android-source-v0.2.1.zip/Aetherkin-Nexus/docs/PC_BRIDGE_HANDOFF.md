# PC / VEILFORGE bridge handoff (read this before queueing)

Intent: standalone, independent private GitHub project and approved Windows workspace called **Aetherkin-Nexus**. Do not store complete game source in Trion-Assistant-Lab bridge. The source archive is currently delivered as a downloadable ChatGPT artifact; the PC cannot access `sandbox:/...` by itself. The owner must make the complete source accessible to the approved PC before a local bootstrap can execute.

Existing infrastructure: `timmytwopointoh/Trion-Assistant-Lab`, `veilforge-link/queue` ↔ `veilforge-link/results`; Windows parent listener. Canonical VEILFORGE Studio remains in its original installed workspace, VQ technique engine from `timmytwopointoh/Engine-build` is read-only input. Existing priority tasks include Realm/Rovekin, Sector Uprising II and Peks Plunder. No modifications, resets, installs or GitHub Actions.

## Phase 0 — prerequisites and no-conflict gate

- PC parent listener running and owner-approved? Do not assume GitHub queue makes this true.
- Other PC worker or emulator tasks active? Defer rather than collide. Keep source checkouts isolated.
- Source bundle present locally at an explicitly approved path and checksum recorded? No confidential files.
- Approved workspace root explicitly provided by existing parent. Never guess a personal directory or scan unrelated drives.
- Private repo name `timmytwopointoh/Aetherkin-Nexus` verified absent; if present stop/read-only inspect.

## Phase 1 — create private repository and workspace, no installations

Review the script `pc/setup-aetherkin-workspace.ps1`, then in the **authorized PC parent session** with an explicitly chosen safe workspace root and the extracted full archive folder, run:

```powershell
.\pc\setup-aetherkin-workspace.ps1 -WorkspaceRoot '<approved root>' -SourceFolder '<folder with project.godot>' -PublishPrivateGitHub
```

The script validates 360 unique creature IDs, checks required source, refuses existing targets, creates an isolated local folder, runs optional source QA, and uses existing authenticated `gh repo create ... --private` to publish. It does not install software, clear existing files or touch installed VEILFORGE. A result report must distinguish actual run, declined/blocked and unverified assumptions.

## Phase 2 — first real run / assets

Use already-installed Godot if permitted; do not claim there was a successful launch until screenshots, logs and a smoke test are returned. First actual gate: 6 zones load; weaken/capture/transform/codex/save/relaunch, realistic frame rate; keyboard controls and portal interaction; 360 entry lookup. Fix any GDScript errors found. Avoid confusing procedural blockout motions with top-notch anime animation.

## Phase 3 — optional VEILFORGE/VQ integration (review-gated)

Create interface adapters in this project's private repository only: geometry request → VQ procedural mesh output → provenance+hash → VQ visual QA → imported creature mesh → artist animation rig → local game preview → screenshot/trace feedback. Use approved immutable engine commits; copy no private credentials, install state or game assets. Advanced authored rigs and multiplayer are subsequent milestones.

## Safety

- No automatic GitHub Actions / hosted compute.
- No new app signing keys, Android installs, phone pairing changes.
- No overwriting shared engine / Peks / Sector / Minecraft source.
- No unsupported claims: creation, compilation, live PC verification and multiplayer must be reported separately.
