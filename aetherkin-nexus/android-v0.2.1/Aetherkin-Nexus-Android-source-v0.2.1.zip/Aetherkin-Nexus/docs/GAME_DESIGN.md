# Aetherkin Nexus — Original action creature RPG

Status: early, offline, source-only Godot 4 vertical-slice prototype. Not a finished polished game, not a compiled Windows executable, not multiplayer.

## Core fantasy

A living dimensional city called Nexus Citadel connects vast, beautiful realms. Adventurers explore for original intelligent creatures and earn their trust by weakening and synchronizing their essence. Each newly captured form is saved to a personal collection, and the player **becomes** the creature in real-time exploration and combat. The arena lets the player experiment and eventually challenge other players.

## Direct gameplay loop implemented in source

1. Spawn as a human explorer in central hub.
2. Travel through one of four landscape gateways.
3. Find roaming wild creatures with behavior, HP and elemental identity.
4. Fight using basic strike and area skill; bring the creature below 42% health; press E near it to capture, with a retryable chance.
5. The ID enters the local saved permanent collection. Press T to become it. Press C to change active form; press Tab for collection UI.
6. Return to hub; enter arena and defeat creature opponents with selected form.

## Included prototype regions

- Nexus Citadel — hub / gates / central plaza.
- Viridian Wilds — verdant tree realm.
- Ashfall Crater — volcanic realm.
- Glacier Crown — frozen crystal realm.
- Tempest Mesa — violet storm realm.
- Ascension Arena — offline AI encounters.

## 360 creature roster (procedural prototypes, **not** 360 authored hero assets)

12 anatomical families: Wyvern, Lynx, Golem, Wisp, Mantis, Serpent, Guardian, Stag, Raptor, Scarab, Chimera, Sprite.
Six elements: Ember, Tide, Volt, Verdant, Terra, Frost.
Five strains: Feral, Valiant, Prime, Ancient, Eclipse.
12 x 6 x 5 = 360 unique playable *data IDs*, names, HP, power, speeds, seed/rarity, capture difficulty, and procedural form selection. Morph variants are shared blockout rigs. **Only the architecture and basic procedural appearance are implemented.**

## Full game ambition

- 300+ individually identifiable fully authored species, each modeled at various LODs, with facial shape keys and skeletons.
- Anime-accurate timing: squash-and-stretch, impactful anticipation/recovery, hand-painted toon ramps, outlines, rim lighting, animated reactions, and strong silhouettes.
- Character-aware locomotion, sprint, glide, climb, slide, stagger, hurt, guard, combo, and 3–4 signature moves per creature.
- Special capture quests, unlocks from environmental puzzles, bosses and creature relationships; no paid loot boxes by default.
- Fully functioning co-op exploration and arena PvP after authoritative-server and cheating/security groundwork.

## Creature animation quality plan

The blockout has parametric bob/swing/wing flutter; this is a technical substitute only. The production system needs:
- 12 rig profiles with standardized bones and retargeted AnimationTree motion graphs (Idle/Walk/Run/Dash/Jump/Fall/Attack/Skill/Hurt/KO/Transform).
- Strong hand-keyed attack anticipation + fast contact + held recovery frames; animation events drive VFX, sound and hit confirmation.
- Grounding through foot IK and ledge test; mesh/camera separation to keep transformations stable.
- Creature-specific eyes/mouths, tail and wing secondaries, cloth/hair spring chains, blend shape expression.
- CPU/GPU profiling and animation quality gates on user's 6GB GTX 1060; choose GL Compatibility as initial baseline and profile upgraded pipelines separately.
- Distinct quality scoring for authored assets: anatomy, movement, arcs, rig clipping, contact, hair/skin, expressive posing, LOD and framerate. Never confuse a passed parser/static test with excellent animation quality.

## Multiplayer design seam (NOT IMPLEMENTED)

Future multiplayer: authoritative dedicated battle server, stable creature and attack IDs, deterministic combat event sequences, prediction/reconciliation, server validation of captures, encrypted transport with rotating sessions, separate saves, server lobbies, matchmaking and anti-cheat. Do not trust a client-supplied captured ID in competitive mode. Avoid launching any network service until approved.

## Originality

Research inspiration: scanning/discovering creatures and fighting as creatures in a fantasy dimension; no Chaotic characters, location names, cards, trademark, UI, plot, artwork or music copied. No proprietary VEILFORGE source embedded: future imports from VQ require license/provenance review and owner-approved isolated adapters.
