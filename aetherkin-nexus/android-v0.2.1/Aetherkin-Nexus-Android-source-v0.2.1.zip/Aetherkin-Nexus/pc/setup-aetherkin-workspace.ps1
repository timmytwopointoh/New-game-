# Aetherkin Nexus: standalone project from a complete, owner-reviewed source folder.
# DO NOT run from a GitHub/ChatGPT queue without PC PARENT workspace authorization.
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$WorkspaceRoot,
  [Parameter(Mandatory=$true)][string]$SourceFolder,
  [switch]$PublishPrivateGitHub,
  [string]$RepoFullName = 'timmytwopointoh/Aetherkin-Nexus'
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
function Need([bool]$ok, [string]$msg) { if (-not $ok) { throw $msg } }
$root = [System.IO.Path]::GetFullPath($WorkspaceRoot)
$src = [System.IO.Path]::GetFullPath($SourceFolder)
Need (Test-Path -LiteralPath $root -PathType Container) 'Approved WorkspaceRoot must already exist. Nothing created.'
Need (Test-Path -LiteralPath $src -PathType Container) 'The complete Aetherkin source directory is required.'
Need (Test-Path -LiteralPath (Join-Path $src 'project.godot') -PathType Leaf) 'Source missing project.godot.'
Need (Test-Path -LiteralPath (Join-Path $src 'data\creatures.json') -PathType Leaf) 'Source missing creature catalog.'
Need (Test-Path -LiteralPath (Join-Path $src 'game\main.gd') -PathType Leaf) 'Source missing gameplay implementation.'
Need ($RepoFullName -eq 'timmytwopointoh/Aetherkin-Nexus') 'Repository name does not match expected scope.'
$target = Join-Path $root 'Aetherkin-Nexus'
Need (-not (Test-Path -LiteralPath $target)) 'Target already exists; inspect and resolve manually, do NOT overwrite.'
Need ($src -ne $root) 'SourceFolder must not be WorkspaceRoot.'
$catalog = Get-Content -LiteralPath (Join-Path $src 'data\creatures.json') -Raw | ConvertFrom-Json
Need ($catalog.Count -eq 360) ('Expected 360 roster entries, got ' + $catalog.Count)
Need ((@($catalog | Select-Object -ExpandProperty id -Unique)).Count -eq 360) 'Duplicate creature IDs.'
if ($PublishPrivateGitHub) {
  Need ([bool](Get-Command gh -ErrorAction SilentlyContinue)) 'Existing authorized gh CLI was not found; no installs attempted.'
  Need ([bool](Get-Command git -ErrorAction SilentlyContinue)) 'Existing Git CLI was not found; no installs attempted.'
  & gh repo view $RepoFullName --json name 2>$null | Out-Null
  Need ($LASTEXITCODE -ne 0) 'GitHub repository already exists or response is ambiguous; refusing to overwrite.'
}
Write-Host ('Validated complete source, 360 unique records; target: ' + $target)
New-Item -ItemType Directory -Path $target -ErrorAction Stop | Out-Null
Get-ChildItem -LiteralPath $src -Force | Where-Object { $_.Name -notin @('.git','.godot') } | ForEach-Object {
  Copy-Item -LiteralPath $_.FullName -Destination $target -Recurse -Force
}
if (Get-Command python -ErrorAction SilentlyContinue) {
  & python (Join-Path $target 'tools\test_catalog.py')
  Need ($LASTEXITCODE -eq 0) 'Source QA failed; private repo has NOT been created.'
}
if (-not $PublishPrivateGitHub) {
  Write-Host 'Standalone local workspace created. Publishing not requested; nothing pushed.'
  return
}
Push-Location -LiteralPath $target
try {
  & git init -b main
  Need ($LASTEXITCODE -eq 0) 'git init failed'
  & git add .
  Need ($LASTEXITCODE -eq 0) 'git add failed'
  & git commit -m 'Initial original Aetherkin Nexus creature RPG prototype'
  Need ($LASTEXITCODE -eq 0) 'git commit failed; check repo-local author configuration, do not edit global settings.'
  & gh repo create $RepoFullName --private --source . --remote origin --push
  Need ($LASTEXITCODE -eq 0) 'Private repository publish failed; check GitHub and local status without resetting.'
  & gh repo view $RepoFullName --json name,visibility,url
  Need ($LASTEXITCODE -eq 0) 'Private repository verification failed.'
  Write-Host 'Private project repository creation command completed; inspect above verification.'
} finally { Pop-Location }
