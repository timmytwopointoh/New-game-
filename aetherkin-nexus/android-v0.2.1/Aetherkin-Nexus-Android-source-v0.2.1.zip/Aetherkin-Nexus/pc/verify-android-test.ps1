# Project-specific Android test procedure; run ONLY on owner-approved Windows PC parent.
# This script has no installer, no device discovery and no key provisioning.
# Require explicit executable locations; never modify global settings or another app.
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$ProjectRoot,
  [Parameter(Mandatory=$true)][string]$GodotExe,
  [Parameter(Mandatory=$true)][ValidateSet('Android Phone ARM64','Android Emulator x86_64')][string]$Preset,
  [string]$AdbExe = '',
  [string]$EmulatorSerial = '',
  [switch]$InstallEmulator
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
function Require([bool]$ok,[string]$message) { if (-not $ok) { throw $message } }
$root = [IO.Path]::GetFullPath($ProjectRoot)
$godot = [IO.Path]::GetFullPath($GodotExe)
Require (Test-Path -LiteralPath (Join-Path $root 'project.godot') -PathType Leaf) 'ProjectRoot must contain the independent Aetherkin project.godot.'
Require (Test-Path -LiteralPath $godot -PathType Leaf) 'Godot executable not present at supplied approved path.'
Require (Test-Path -LiteralPath (Join-Path $root 'mobile\touch_controls.gd') -PathType Leaf) 'Mobile controls missing.'
Require (Test-Path -LiteralPath (Join-Path $root 'export_presets.cfg') -PathType Leaf) 'Android export presets missing.'
Require ($Preset -eq 'Android Emulator x86_64' -or -not $InstallEmulator) 'Emulator install requires x86_64 emulator preset to avoid ARM64 ABI mismatch.'
$apkName = 'Aetherkin-Nexus-Android-v0.2-x86_64.apk'
if ($Preset -eq 'Android Phone ARM64') { $apkName = 'Aetherkin-Nexus-Android-v0.2-ARM64.apk' }
$build = Join-Path $root 'build'
if (-not (Test-Path -LiteralPath $build)) { New-Item -Path $build -ItemType Directory | Out-Null }
$apk = Join-Path $build $apkName
Write-Host '=== Aetherkin independent Android QA ==='
Write-Host 'Step 1: editor import and parse; cannot publish APK if this fails.'
& $godot --headless --path $root --editor --quit
Require ($LASTEXITCODE -eq 0) 'Godot editor import failed: inspect local output and fix GDScript before exporting.'
Write-Host 'Step 2: headless runtime smoke (240 frames).'
& $godot --headless --path $root --quit-after 240
Require ($LASTEXITCODE -eq 0) 'Godot runtime smoke failed.'
Write-Host 'Step 3: export debug test APK with existing local SDK/export templates.'
& $godot --headless --path $root --export-debug $Preset $apk
Require ($LASTEXITCODE -eq 0) 'Godot APK export failed. Check Android SDK/JDK, export templates and locally configured debug signing; no new secrets created.'
Require (Test-Path -LiteralPath $apk -PathType Leaf) 'Godot reported export but APK does not exist.'
$info = Get-Item -LiteralPath $apk
Require ($info.Length -gt 1000000) 'APK too small: likely not a valid Godot runtime package.'
$hash = (Get-FileHash -LiteralPath $apk -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host ('APK bytes: ' + $info.Length)
Write-Host ('APK SHA256: ' + $hash)
Write-Host 'Debug signing only: do not call it the permanent production signing identity.'
if ($InstallEmulator) {
  Require ($EmulatorSerial -match '^emulator-[0-9]+$') 'Only the explicitly owner-approved local emulator-#### target is permitted, never physical devices.'
  Require ($AdbExe -ne '') 'AdbExe path required to select the approved emulator explicitly.'
  $adb = [IO.Path]::GetFullPath($AdbExe)
  Require (Test-Path -LiteralPath $adb -PathType Leaf) 'Approved adb.exe not present at supplied path.'
  $state = (& $adb -s $EmulatorSerial get-state 2>&1 | Out-String).Trim()
  Require ($LASTEXITCODE -eq 0 -and $state -eq 'device') 'Selected emulator not online/authorized; do not target a different device.'
  $abi = (& $adb -s $EmulatorSerial shell getprop ro.product.cpu.abi | Out-String).Trim()
  Require ($abi -eq 'x86_64') ('This preset requires x86_64 emulator ABI; got ' + $abi)
  Write-Host 'Step 4: install -r to approved emulator ONLY; never uninstall or reset saves.'
  & $adb -s $EmulatorSerial install -r $apk
  Require ($LASTEXITCODE -eq 0) 'ADB install -r failed; stop, inspect signing/ABI locally; never uninstall another package.'
  & $adb -s $EmulatorSerial shell monkey -p com.veilforge.aetherkinnexus -c android.intent.category.LAUNCHER 1
  Require ($LASTEXITCODE -eq 0) 'ADB launcher intent failed. Inspect game output and graphics on emulator before declaring gameplay success.'
  Write-Host 'Emulator launched via ADB; visual/touch/movement/capture/codex/save tests STILL require actual observations.'
}
Write-Host '=== End: report exact passed stages and unresolved emulator gameplay tests ==='
