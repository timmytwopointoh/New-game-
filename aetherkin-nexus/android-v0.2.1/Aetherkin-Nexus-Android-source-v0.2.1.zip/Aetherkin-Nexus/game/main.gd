extends Node3D
## Aetherkin Nexus offline single-player vertical slice. No network, telemetry or copyrighted Chaotic content.

const Visual = preload("res://engine/creature_visual.gd")
const World = preload("res://engine/world_builder.gd")
const Touch = preload("res://mobile/touch_controls.gd")
const SAVE_PATH := "user://aetherkin_save_v1.json"
const START_HP := 180.0

var catalog: Array = []
var by_id: Dictionary = {}
var owned: Array[String] = []
var scanned: Array[String] = []
var active_id := ""
var transformed := false
var current_zone := "hub"
var world
var player: CharacterBody3D
var hero_visual
var camera: Camera3D
var yaw := 0.0
var pitch := -0.35
var enemies: Array = []
var rng := RandomNumberGenerator.new()
var player_hp := START_HP
var combo_count := 0
var attack_timer := 0.0
var skill_timer := 0.0
var effect_timer := 0.0
var message_time := 0.0
var message := ""
var ui_top: Label
var ui_bottom: Label
var ui_middle: Label
var ui_roster: ItemList
var ui_codex_title: Label
var touch_ui
var mobile_mode := false
var ui_panel: PanelContainer
var roster_visible := false
var paused_mouse := false
var pulse_effects: Array = []
var arena_wins := 0

func _ready() -> void:
    rng.randomize()
    mobile_mode = OS.has_feature("android") or bool(ProjectSettings.get_setting("aetherkin/force_touch_controls", false))
    if mobile_mode:
        Engine.max_fps = 45
    _read_catalog()
    _load_save()
    _register_inputs()
    _lighting()
    world = World.new()
    add_child(world)
    player = CharacterBody3D.new()
    player.name = "Explorer"
    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.42
    capsule.height = 2.0
    collision.shape = capsule
    collision.position.y = 1.1
    player.add_child(collision)
    add_child(player)
    hero_visual = Visual.new()
    player.add_child(hero_visual)
    _apply_avatar()
    camera = Camera3D.new()
    camera.current = true
    camera.fov = 68.0
    camera.far = 150.0
    add_child(camera)
    _make_hud()
    touch_ui = Touch.new()
    add_child(touch_ui)
    _enter_zone("hub")
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if mobile_mode else Input.MOUSE_MODE_CAPTURED
    if mobile_mode:
        _say("MOVE with the left stick; swipe to look. CAPTURE a weakened creature.", 7.0)
    else:
        _say("Explore a gateway. Weaken a wild creature, then press E to capture its form!", 7.0)

func _read_catalog() -> void:
    var file := FileAccess.open("res://data/creatures.json", FileAccess.READ)
    if file == null:
        push_error("Missing data/creatures.json")
        return
    var payload = JSON.parse_string(file.get_as_text())
    if not (payload is Array):
        push_error("Creature catalog is not an array")
        return
    catalog = payload
    for creature in catalog:
        if creature is Dictionary and creature.has("id"):
            by_id[str(creature["id"])] = creature

func _register_inputs() -> void:
    var mapping := {
        "ak_forward": KEY_W, "ak_back": KEY_S, "ak_left": KEY_A, "ak_right": KEY_D,
        "ak_attack": KEY_J, "ak_skill": KEY_Q, "ak_use": KEY_E,
        "ak_cycle": KEY_C, "ak_morph": KEY_T, "ak_collection": KEY_TAB,
        "ak_dash": KEY_SHIFT, "ak_jump": KEY_SPACE
    }
    for action in mapping:
        if not InputMap.has_action(action):
            InputMap.add_action(action)
        var key := InputEventKey.new()
        key.physical_keycode = int(mapping[action])
        InputMap.action_add_event(action, key)

func _lighting() -> void:
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-49, -31, 0)
    sun.light_energy = 1.55
    sun.shadow_enabled = not mobile_mode
    add_child(sun)
    var env := WorldEnvironment.new()
    var scene_env := Environment.new()
    scene_env.background_mode = Environment.BG_COLOR
    scene_env.background_color = Color("#181F39")
    scene_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    scene_env.ambient_light_color = Color("#7A90B8")
    scene_env.ambient_light_energy = 0.73
    scene_env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.environment = scene_env
    add_child(env)

func _make_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var top_panel := PanelContainer.new()
    top_panel.set_anchors_preset(Control.PRESET_TOP_WIDE)
    top_panel.offset_bottom = 87.0
    layer.add_child(top_panel)
    ui_top = Label.new()
    ui_top.add_theme_font_size_override("font_size", 22)
    ui_top.add_theme_color_override("font_color", Color("#DDF8FF"))
    ui_top.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    top_panel.add_child(ui_top)
    var bottom_panel := PanelContainer.new()
    bottom_panel.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    bottom_panel.offset_top = -100.0
    layer.add_child(bottom_panel)
    ui_bottom = Label.new()
    ui_bottom.add_theme_font_size_override("font_size", 20)
    ui_bottom.add_theme_color_override("font_color", Color("#BCECEC"))
    ui_bottom.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    bottom_panel.add_child(ui_bottom)
    ui_middle = Label.new()
    ui_middle.set_anchors_preset(Control.PRESET_CENTER)
    ui_middle.offset_left = -450
    ui_middle.offset_right = 450
    ui_middle.offset_top = -20
    ui_middle.offset_bottom = 45
    ui_middle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    ui_middle.add_theme_font_size_override("font_size", 24)
    ui_middle.add_theme_color_override("font_color", Color("#FFE29B"))
    layer.add_child(ui_middle)
    ui_panel = PanelContainer.new()
    ui_panel.set_anchors_preset(Control.PRESET_CENTER)
    ui_panel.offset_left = -390
    ui_panel.offset_right = 390
    ui_panel.offset_top = -280
    ui_panel.offset_bottom = 280
    layer.add_child(ui_panel)
    var layout := VBoxContainer.new()
    layout.add_theme_constant_override("separation", 8)
    ui_panel.add_child(layout)
    ui_codex_title = Label.new()
    ui_codex_title.add_theme_font_size_override("font_size", 23)
    layout.add_child(ui_codex_title)
    ui_roster = ItemList.new()
    ui_roster.size_flags_vertical = Control.SIZE_EXPAND_FILL
    ui_roster.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    ui_roster.add_theme_font_size_override("font_size", 22)
    ui_roster.item_selected.connect(_on_codex_selected)
    layout.add_child(ui_roster)
    var commands := HBoxContainer.new()
    layout.add_child(commands)
    var become := Button.new()
    become.text = "BECOME SELECTED"
    become.custom_minimum_size = Vector2(225, 58)
    become.pressed.connect(_morph_from_codex)
    commands.add_child(become)
    var close := Button.new()
    close.text = "CLOSE"
    close.custom_minimum_size = Vector2(140, 58)
    close.pressed.connect(_close_roster)
    commands.add_child(close)
    ui_panel.visible = false

func _unhandled_input(event: InputEvent) -> void:
    if mobile_mode and not roster_visible and event is InputEventScreenDrag:
        yaw -= event.relative.x * 0.0043
        pitch = clamp(pitch - event.relative.y * 0.0030, -0.72, 0.1)
    elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        yaw -= event.relative.x * 0.0034
        pitch = clamp(pitch - event.relative.y * 0.0021, -0.72, 0.1)
    elif event is InputEventKey and event.pressed and not event.echo:
        if event.physical_keycode == KEY_ESCAPE:
            if roster_visible:
                _close_roster()
            elif not mobile_mode:
                paused_mouse = not paused_mouse
                Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if paused_mouse else Input.MOUSE_MODE_CAPTURED
        elif event.physical_keycode == KEY_F5:
            _save()
            _say("Collection saved.")
    elif not mobile_mode and event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        if Input.mouse_mode == Input.MOUSE_MODE_VISIBLE:
            paused_mouse = false
            Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
        else:
            _attack(false)

func _physics_process(delta: float) -> void:
    if player == null:
        return
    attack_timer = maxf(attack_timer - delta, 0.0)
    skill_timer = maxf(skill_timer - delta, 0.0)
    effect_timer = maxf(effect_timer - delta, 0.0)
    message_time = maxf(message_time - delta, 0.0)
    var input_vector := Input.get_vector("ak_left", "ak_right", "ak_forward", "ak_back")
    if mobile_mode and is_instance_valid(touch_ui) and touch_ui.touch_enabled:
        input_vector = (input_vector + touch_ui.movement).limit_length(1.0)
    if roster_visible or paused_mouse:
        input_vector = Vector2.ZERO
    var f := Vector3(-sin(yaw), 0, -cos(yaw))
    var r := Vector3(cos(yaw), 0, -sin(yaw))
    var direction := r * input_vector.x - f * input_vector.y
    if direction.length_squared() > 1.0:
        direction = direction.normalized()
    var speed := 7.0
    if transformed and by_id.has(active_id):
        speed = float(by_id[active_id].get("speed", 7.0)) + 1.0
    if Input.is_action_pressed("ak_dash"):
        speed *= 1.48
    player.velocity.x = move_toward(player.velocity.x, direction.x * speed, delta * 24.0)
    player.velocity.z = move_toward(player.velocity.z, direction.z * speed, delta * 24.0)
    if player.is_on_floor():
        if Input.is_action_just_pressed("ak_jump"):
            player.velocity.y = 7.0
        else:
            player.velocity.y = -0.3
    else:
        player.velocity.y -= 16.0 * delta
    player.move_and_slide()
    player.position.x = clampf(player.position.x, -43.0, 43.0)
    player.position.z = clampf(player.position.z, -43.0, 43.0)
    if is_instance_valid(hero_visual):
        if direction.length() > 0.12:
            hero_visual.rotation.y = lerp_angle(hero_visual.rotation.y, atan2(-direction.x, -direction.z), delta * 9.0)
        hero_visual.advance(delta, minf(direction.length(), 1.0), effect_timer > 0.0)
    var focus := player.global_position + Vector3(0, 1.7, 0)
    var arm := Vector3(sin(yaw)*cos(pitch), -sin(pitch), cos(yaw)*cos(pitch))
    var ideal := focus + arm * 9.8 + Vector3(0, 2.0, 0)
    camera.global_position = camera.global_position.lerp(ideal, minf(delta * 7.5, 1.0))
    camera.look_at(focus + Vector3(0, 0.6, 0), Vector3.UP)
    _update_ai(delta)
    _update_effects(delta)
    _check_actions()
    _refresh_hud()

func _check_actions() -> void:
    if roster_visible:
        if Input.is_action_just_pressed("ak_collection"):
            roster_visible = false
            ui_panel.visible = false
            Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if mobile_mode else Input.MOUSE_MODE_CAPTURED
        return
    if Input.is_action_just_pressed("ak_attack"):
        _attack(false)
    if Input.is_action_just_pressed("ak_skill"):
        _attack(true)
    if Input.is_action_just_pressed("ak_cycle"):
        _cycle_form()
    if Input.is_action_just_pressed("ak_morph"):
        _morph()
    if Input.is_action_just_pressed("ak_collection"):
        _show_roster()
    if Input.is_action_just_pressed("ak_use"):
        for gate in world.portals:
            if _ground_distance(player.position, gate["position"]) < 3.8:
                _enter_zone(str(gate["target"]))
                return
        _capture()

func _enter_zone(zone: String) -> void:
    current_zone = zone
    world.build(zone)
    for enemy in enemies:
        if is_instance_valid(enemy["node"]):
            enemy["node"].queue_free()
    enemies.clear()
    pulse_effects.clear()
    player.position = Vector3(0, 0.13, 8.0 if zone == "hub" else 5.0)
    player.velocity = Vector3.ZERO
    player_hp = START_HP
    if zone != "hub":
        _spawn_enemies(zone)
    _say("Entered %s" % World.ZONE_NAMES[zone], 3.2)

func _spawn_enemies(zone: String) -> void:
    var element: String = str({"verdant":"Verdant", "ember":"Ember", "frost":"Frost", "volt":"Volt"}.get(zone, ""))
    var pool: Array = []
    for spec in catalog:
        if zone == "arena":
            if str(spec["rarity"]) in ["common", "uncommon", "rare"]:
                pool.append(spec)
        elif str(spec["element"]) == element and str(spec["rarity"]) in ["common", "uncommon", "rare"]:
            pool.append(spec)
    if pool.is_empty():
        return
    var enemy_count := (6 if zone == "arena" else 9) if mobile_mode else (11 if zone == "arena" else 17)
    for i in range(enemy_count):
        var selection: Dictionary = pool[rng.randi_range(0, pool.size()-1)]
        var actor := Node3D.new()
        actor.position = Vector3(rng.randf_range(-32, 32), 0.08, rng.randf_range(-33, -8))
        world.zone_root.add_child(actor)
        var visual = Visual.new()
        actor.add_child(visual)
        visual.set_creature(selection)
        enemies.append({
            "node": actor, "visual": visual, "spec": selection,
            "hp": float(selection["hp"]), "max_hp": float(selection["hp"]),
            "cooldown": rng.randf_range(0.5, 2.5), "heading": rng.randf_range(-PI, PI),
            "walk_time": rng.randf_range(0.5, 3.0), "stun": 0.0
        })

func _update_ai(delta: float) -> void:
    if current_zone == "hub":
        return
    for enemy in enemies:
        var actor: Node3D = enemy["node"]
        if not is_instance_valid(actor) or float(enemy["hp"]) <= 0:
            continue
        enemy["stun"] = maxf(0.0, float(enemy["stun"]) - delta)
        enemy["cooldown"] = maxf(0.0, float(enemy["cooldown"]) - delta)
        enemy["walk_time"] = float(enemy["walk_time"]) - delta
        var dist := _ground_distance(actor.position, player.position)
        var dir := Vector3.ZERO
        if dist < 12.0 and dist > 2.4:
            dir = (player.position - actor.position).normalized()
        elif dist >= 12.0:
            if float(enemy["walk_time"]) < 0.0:
                enemy["heading"] = rng.randf_range(-PI, PI)
                enemy["walk_time"] = rng.randf_range(1.4, 3.2)
            dir = Vector3(sin(float(enemy["heading"])), 0, cos(float(enemy["heading"])))
        if float(enemy["stun"]) <= 0:
            actor.position += dir * delta * (2.0 if dist < 12 else 0.65)
        actor.position.x = clampf(actor.position.x, -39, 39)
        actor.position.z = clampf(actor.position.z, -39, 39)
        if dir.length() > 0.1:
            actor.rotation.y = lerp_angle(actor.rotation.y, atan2(-dir.x, -dir.z), delta * 4.0)
        enemy["visual"].advance(delta, 0.55 if dir.length() > 0.1 else 0.12, float(enemy["stun"]) > 0.4)
        if dist < 2.8 and float(enemy["cooldown"]) <= 0.0 and float(enemy["stun"]) <= 0:
            enemy["cooldown"] = 1.8
            player_hp -= 7.0 + float(enemy["spec"]["attack"]) * 0.25
            _pulse(player.position + Vector3(0, 1.2, 0), Color("#FF695E"))
            if player_hp <= 0.0:
                _enter_zone("hub")
                _say("You were defeated. Returned safely to Nexus Citadel.", 5.0)
                return

func _attack(special: bool) -> void:
    if roster_visible or current_zone == "hub":
        return
    if (skill_timer if special else attack_timer) > 0.0:
        return
    if special:
        skill_timer = 7.8
    else:
        attack_timer = 0.48
    effect_timer = 0.35
    var tint := Color("#FFDF90")
    var power := 20.0
    if transformed and by_id.has(active_id):
        var s: Dictionary = by_id[active_id]
        tint = Color.html(str(s["color"]))
        power = float(s["attack"]) * (2.0 if special else 1.12)
    var reach := 7.0 if special else 4.2
    _pulse(player.position + Vector3(0, 1.0, 0), tint, 2.3 if special else 1.2)
    var hit := 0
    for enemy in enemies:
        var actor: Node3D = enemy["node"]
        if not is_instance_valid(actor) or float(enemy["hp"]) <= 0.0:
            continue
        if _ground_distance(actor.position, player.position) <= reach:
            enemy["hp"] = maxf(0.0, float(enemy["hp"]) - power)
            enemy["stun"] = 0.45
            _pulse(actor.position + Vector3(0, 1.2, 0), tint)
            hit += 1
            if float(enemy["hp"]) <= 0:
                actor.visible = false
                if current_zone == "arena":
                    arena_wins += 1
    if hit > 0:
        combo_count += 1
        _say("%s hit %d target%s  •  Combo %d" % ["Skill" if special else "Strike", hit, "s" if hit != 1 else "", combo_count], 1.3)

func _capture() -> void:
    if current_zone in ["hub", "arena"]:
        _say("Capture wild creatures in the exploration realms.")
        return
    var candidate: Dictionary = {}
    var nearest := 5.2
    for enemy in enemies:
        if not is_instance_valid(enemy["node"]) or float(enemy["hp"]) <= 0:
            continue
        var d := _ground_distance(player.position, enemy["node"].position)
        if d < nearest:
            nearest = d
            candidate = enemy
    if candidate.is_empty():
        _say("Approach a living wild creature to capture it.")
        return
    if float(candidate["hp"]) > float(candidate["max_hp"]) * 0.42:
        _say("Weaken %s below 42%% health first." % candidate["spec"]["name"])
        return
    var spec: Dictionary = candidate["spec"]
    var cid := str(spec["id"])
    var success_chance := 0.92 - float(spec["capture_difficulty"]) * 0.35
    if rng.randf() > success_chance:
        _say("Capture disrupted! Weaken it further and try again.", 3.0)
        return
    if not owned.has(cid):
        owned.append(cid)
    if not scanned.has(cid):
        scanned.append(cid)
    active_id = cid
    candidate["hp"] = 0.0
    candidate["node"].visible = false
    _pulse(candidate["node"].position + Vector3.UP, Color("#75FFDD"), 2.8)
    _save()
    _say("CAPTURED: %s. Use TRANSFORM to become it!" % str(spec["name"]), 4.3)

func _morph() -> void:
    if active_id.is_empty() or not owned.has(active_id):
        _say("Capture a creature in a wild realm before transforming.")
        return
    transformed = not transformed
    _apply_avatar()
    var title := str(by_id[active_id]["name"]) if transformed else "Explorer"
    _pulse(player.position + Vector3(0, 1.0, 0), Color("#CFA1FF"), 2.6)
    _say("Transformation: %s" % title)
    _save()

func _cycle_form() -> void:
    if owned.is_empty():
        _say("Your collection is empty — capture a creature first.")
        return
    var idx := owned.find(active_id)
    active_id = owned[(idx + 1) % owned.size()]
    if transformed:
        _apply_avatar()
    _say("Selected %s — press T to transform." % str(by_id[active_id]["name"]), 2.2)
    _save()

func _apply_avatar() -> void:
    if is_instance_valid(hero_visual):
        hero_visual.queue_free()
    hero_visual = Visual.new()
    player.add_child(hero_visual)
    if transformed and by_id.has(active_id):
        hero_visual.set_creature(by_id[active_id])
    else:
        hero_visual.set_creature({"family":"Guardian", "color":"#BFB4E6", "variant_seed":5})
        hero_visual.scale = Vector3.ONE * 0.72

func _show_roster() -> void:
    roster_visible = true
    ui_panel.visible = true
    if mobile_mode and is_instance_valid(touch_ui):
        touch_ui.visible = false
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    ui_codex_title.text = "AETHERKIN CODEX    %d / %d captured" % [owned.size(), catalog.size()]
    ui_roster.clear()
    if owned.is_empty():
        ui_roster.add_item("None yet. Find a wild creature and capture it.")
        ui_roster.set_item_disabled(0, true)
        return
    for cid in owned:
        var creature: Dictionary = by_id.get(cid, {})
        var label := str(creature.get("name", cid))
        if cid == active_id:
            label += "    ◀ SELECTED"
        ui_roster.add_item(label)
        var n := ui_roster.get_item_count() - 1
        ui_roster.set_item_metadata(n, cid)
        if cid == active_id:
            ui_roster.select(n)
            ui_roster.ensure_current_is_visible()

func _on_codex_selected(index: int) -> void:
    if index < 0 or index >= ui_roster.get_item_count():
        return
    var cid := str(ui_roster.get_item_metadata(index))
    if not owned.has(cid):
        return
    active_id = cid
    if transformed:
        _apply_avatar()
    _save()
    ui_codex_title.text = "%s   •   %d/%d captured" % [str(by_id[cid]["name"]), owned.size(), catalog.size()]
    _say("Selected %s" % str(by_id[cid]["name"]))

func _morph_from_codex() -> void:
    _close_roster()
    _morph()

func _close_roster() -> void:
    roster_visible = false
    ui_panel.visible = false
    if mobile_mode and is_instance_valid(touch_ui):
        touch_ui.visible = true
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if mobile_mode else Input.MOUSE_MODE_CAPTURED

func _refresh_hud() -> void:
    var title := str(World.ZONE_NAMES.get(current_zone, "Unknown"))
    var form := "Human Explorer"
    if transformed and by_id.has(active_id):
        form = str(by_id[active_id]["name"])
    if mobile_mode:
        ui_top.text = "  AETHERKIN ALPHA  |  %s  |  HP %d  |  %d/360  |  %s" % [title, int(maxf(0.0, player_hp)), owned.size(), form]
    else:
        ui_top.text = "  AETHERKIN NEXUS    |    %s    |    HP %d / %d    |    Captured %d / 360    |    %s" % [title, int(maxf(0.0, player_hp)), int(START_HP), owned.size(), form]
    var near_gate := ""
    for gate in world.portals:
        if _ground_distance(player.position, gate["position"]) < 4.5:
            near_gate = "  PORTAL: %s" % str(gate["name"])
            break
    var enemy_tip := ""
    if near_gate == "" and not (current_zone in ["hub", "arena"]):
        for enemy in enemies:
            if not is_instance_valid(enemy["node"]) or float(enemy["hp"]) <= 0:
                continue
            if _ground_distance(enemy["node"].position, player.position) < 5.6:
                enemy_tip = "  |  %s HP %d/%d (capture below 42%%)" % [enemy["spec"]["name"], int(enemy["hp"]), int(enemy["max_hp"])]
                break
    if mobile_mode:
        ui_bottom.text = "%s%s" % [near_gate, enemy_tip]
    else:
        ui_bottom.text = "  WASD move  •  Mouse look  •  Space jump  •  Shift dash  •  J/click strike  •  Q special\n  E interact/capture  •  T transform  •  C next form  •  TAB codex  •  Esc mouse  •  F5 save%s%s" % [near_gate, enemy_tip]

    ui_middle.text = message if message_time > 0.0 else ("Arena victories: %d" % arena_wins if current_zone == "arena" else "")

func _pulse(location: Vector3, color: Color, size: float = 1.0) -> void:
    if pulse_effects.size() >= (14 if mobile_mode else 32):
        return
    var node := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radial_segments = 12
    mesh.rings = 6
    node.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(color.r, color.g, color.b, 0.28)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.emission_enabled = true
    mat.emission = color
    mat.emission_energy_multiplier = 2.3
    node.material_override = mat
    node.position = location
    node.scale = Vector3.ONE * 0.2
    add_child(node)
    var duration := 0.83 if size > 2.0 else 0.52
    pulse_effects.append({"node": node, "life": duration, "total": duration, "size": size})

func _update_effects(delta: float) -> void:
    for i in range(pulse_effects.size() - 1, -1, -1):
        var p: Dictionary = pulse_effects[i]
        p["life"] = float(p["life"]) - delta
        if float(p["life"]) <= 0.0:
            if is_instance_valid(p["node"]):
                p["node"].queue_free()
            pulse_effects.remove_at(i)
        else:
            var life_fraction := clampf(float(p["life"]) / float(p["total"]), 0.0, 1.0)
            var growth := 1.0 - life_fraction
            p["node"].scale = Vector3.ONE * float(p["size"]) * (0.20 + 2.8 * growth)
            var material := p["node"].material_override as StandardMaterial3D
            if material != null:
                var faded := material.albedo_color
                faded.a = life_fraction * 0.28
                material.albedo_color = faded
            pulse_effects[i] = p

func _ground_distance(a: Vector3, b: Vector3) -> float:
    return Vector2(a.x - b.x, a.z - b.z).length()

func _say(words: String, duration: float = 2.2) -> void:
    message = words
    message_time = duration

func _save() -> void:
    var payload := {"schema":1, "owned":owned, "scanned":scanned, "active":active_id, "transformed":transformed}
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        push_warning("Could not open save file")
        return
    file.store_string(JSON.stringify(payload, "  "))
    file.close()

func _load_save() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return
    var payload = JSON.parse_string(file.get_as_text())
    if not (payload is Dictionary) or int(payload.get("schema", 0)) != 1:
        return
    for id in payload.get("owned", []):
        if id is String and by_id.has(id) and not owned.has(id):
            owned.append(id)
    for id in payload.get("scanned", []):
        if id is String and by_id.has(id) and not scanned.has(id):
            scanned.append(id)
    var saved_active := str(payload.get("active", ""))
    active_id = saved_active if owned.has(saved_active) else (owned[0] if not owned.is_empty() else "")
    transformed = bool(payload.get("transformed", false)) and not active_id.is_empty()
