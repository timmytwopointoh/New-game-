extends CanvasLayer
## Mobile controls are source-native and do not need an Android plug-in or Internet.
## This overlay is built at runtime so portrait resizing and aspect variations remain anchored.

const JoyScript = preload("res://mobile/joystick.gd")
var movement: Vector2 = Vector2.ZERO
var joystick
var buttons: Array[Button] = []
var touch_enabled := false

func _ready() -> void:
    layer = 11
    touch_enabled = OS.has_feature("android") or bool(ProjectSettings.get_setting("aetherkin/force_touch_controls", false))
    if not touch_enabled:
        return
    var root := Control.new()
    root.name = "TouchHUD"
    root.anchor_right = 1.0
    root.anchor_bottom = 1.0
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(root)
    joystick = JoyScript.new()
    joystick.name = "AnalogMovement"
    joystick.anchor_left = 0.0
    joystick.anchor_right = 0.0
    joystick.anchor_top = 1.0
    joystick.anchor_bottom = 1.0
    joystick.offset_left = 24.0
    joystick.offset_right = 235.0
    joystick.offset_top = -242.0
    joystick.offset_bottom = -31.0
    root.add_child(joystick)
    # x and y are positive distances from the bottom-right safe edge.
    _action(root, "STRIKE", "ak_attack", 20.0, 32.0, 125.0, 88.0, Color("#B94E7D"))
    _action(root, "SPECIAL", "ak_skill", 156.0, 137.0, 126.0, 71.0, Color("#7558CC"))
    _action(root, "CAPTURE / ENTER", "ak_use", 19.0, 134.0, 132.0, 75.0, Color("#318D86"))
    _action(root, "JUMP", "ak_jump", 297.0, 128.0, 103.0, 65.0, Color("#3978B2"))
    _action(root, "DASH", "ak_dash", 158.0, 37.0, 126.0, 65.0, Color("#356D9B"))
    _action(root, "TRANSFORM", "ak_morph", 298.0, 36.0, 124.0, 65.0, Color("#A66CC8"))
    _action(root, "NEXT FORM", "ak_cycle", 439.0, 36.0, 124.0, 65.0, Color("#5573A4"))
    _top_action(root, "CREATURE CODEX", "ak_collection", 22.0, 76.0, 170.0, 56.0)

func _process(_delta: float) -> void:
    if touch_enabled and is_instance_valid(joystick):
        movement = joystick.value

func _action(root: Control, caption: String, action: String, right: float, bottom: float, w: float, h: float, tint: Color) -> void:
    var button := _create_button(root, caption, tint)
    button.anchor_left = 1.0
    button.anchor_right = 1.0
    button.anchor_top = 1.0
    button.anchor_bottom = 1.0
    button.offset_left = -right - w
    button.offset_right = -right
    button.offset_top = -bottom - h
    button.offset_bottom = -bottom
    _bind(button, action)

func _top_action(root: Control, caption: String, action: String, right: float, top: float, w: float, h: float) -> void:
    var button := _create_button(root, caption, Color("#355B7E"))
    button.anchor_left = 1.0
    button.anchor_right = 1.0
    button.anchor_top = 0.0
    button.anchor_bottom = 0.0
    button.offset_left = -right - w
    button.offset_right = -right
    button.offset_top = top
    button.offset_bottom = top + h
    _bind(button, action)

func _create_button(root: Control, caption: String, tint: Color) -> Button:
    var button := Button.new()
    button.text = caption
    button.focus_mode = Control.FOCUS_NONE
    button.mouse_filter = Control.MOUSE_FILTER_STOP
    button.add_theme_font_size_override("font_size", 16)
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(tint.r, tint.g, tint.b, 0.89)
    normal.border_color = Color("#BEEBF8")
    normal.set_border_width_all(2)
    normal.set_corner_radius_all(15)
    var down := normal.duplicate() as StyleBoxFlat
    down.bg_color = tint.lightened(0.22)
    button.add_theme_stylebox_override("normal", normal)
    button.add_theme_stylebox_override("hover", normal)
    button.add_theme_stylebox_override("pressed", down)
    button.add_theme_color_override("font_color", Color.WHITE)
    root.add_child(button)
    buttons.append(button)
    return button

func _bind(button: Button, action: String) -> void:
    button.button_down.connect(func(): Input.action_press(action))
    button.button_up.connect(func(): Input.action_release(action))
    button.visibility_changed.connect(func():
        if not button.visible:
            Input.action_release(action)
    )
