extends Control
## Multi-touch-friendly analog thumbstick; provides analog Vector2, not synthetic key events.

var value := Vector2.ZERO
var active_finger := -1
var mouse_active := false

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_STOP
    focus_mode = Control.FOCUS_NONE
    set_process_unhandled_input(true)
    queue_redraw()

func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and active_finger == -1:
            active_finger = event.index
            _move(event.position)
            accept_event()
        elif not event.pressed and event.index == active_finger:
            active_finger = -1
            value = Vector2.ZERO
            queue_redraw()
            accept_event()
    elif event is InputEventScreenDrag and event.index == active_finger:
        _move(event.position)
        accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            mouse_active = true
            _move(event.position)
        else:
            mouse_active = false
            value = Vector2.ZERO
            queue_redraw()
        accept_event()
    elif event is InputEventMouseMotion and mouse_active:
        _move(event.position)
        accept_event()

func _move(point: Vector2) -> void:
    var origin := size * 0.5
    var radius := maxf(minf(size.x, size.y) * 0.38, 1.0)
    value = ((point - origin) / radius).limit_length(1.0)
    queue_redraw()

func _draw() -> void:
    var origin := size * 0.5
    var radius := minf(size.x, size.y) * 0.38
    draw_circle(origin, radius, Color(0.055, 0.11, 0.20, 0.54))
    draw_arc(origin, radius - 3.0, 0, TAU, 64, Color(0.38, 0.89, 1.0, 0.7), 4.0)
    draw_circle(origin + value * radius, radius * 0.37, Color(0.12, 0.65, 0.83, 0.91))
    draw_arc(origin + value * radius, radius * 0.37, 0, TAU, 36, Color(0.90, 1.0, 1.0, 0.93), 2.4)
