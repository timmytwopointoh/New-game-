# Aetherkin Nexus

Version: 0.1.1 source preview (corrected dynamic script references).
**Original anime-style creature RPG | offline single-player Godot 4 source prototype**

Explore six zones (hub, four creature realms, AI arena); weaken and capture roaming monsters; transform into any captured form; save your collection locally. Contains deterministic 360-entry creature catalog, 12 shared procedural body families, toon-shaded creatures and lightweight 3D geometry. **All creature graphics and animations are temporary procedural blockouts, not top-quality production assets.**

## Run on PC
1. Install a compatible official Godot 4.x editor (GL Compatibility renderer). No third-party plugins are required.
2. Open `project.godot` and press F6 on `scenes/main.tscn`, or F5 to run the main scene.
3. The source uses local saves in `user://aetherkin_save_v1.json`; no login/phone connection/network.
4. Optional source-only verification: `python tools/test_catalog.py`. The Godot runtime was NOT available in the source-authoring environment, so an actual live desktop launch is not claimed.

## Controls

| Control | Action |
|---|---|
| WASD / mouse | Move / look |
| Space / Shift | Jump / dash |
| E | Enter portal or capture weakened nearby creature |
| J or left click | Strike |
| Q | Elemental special AOE |
| T | Transform into selected captured creature, or human |
| C | Cycle through your saved creatures |
| Tab | Open/close creature Codex |
| Esc | Release/capture mouse |
| F5 | Save collection |

## Structure

- `game/main.gd` — main single-player simulation and interface.
- `engine/creature_visual.gd` — reusable 12-family creature blockout visual and motion core.
- `engine/world_builder.gd` — original portal hub, realms and AI arena generation.
- `data/creatures.json` — 360 definition records.
- `tools/generate_catalog.py` — deterministic roster writer.
- `tools/test_catalog.py` — catalog/save/schema static QA.
- `shaders/toon.gdshader` — stylized cel-shader material.
- `docs/GAME_DESIGN.md` — full plan, milestones and artistic standards.
- `pc/setup-aetherkin-workspace.ps1` — optional **owner-reviewed** PRIVATE repository bootstrap in a separately approved PC workspace.

## Safety and project separation

No GitHub Actions, automatic install, existing VEILFORGE/Engine-build files, VQ runtime, Minecraft, Peks, Sector Uprising or signing material are modified. Offline testing is manual. The PC bridge can be used for a bounded staging request only; a queue message is **not** proof of actual PC execution.

## Status

- Implemented as source: 360 deterministic capture IDs, procedural monster silhouettes, transformation, zones, AI encounters, basic skills, persistent save, single-player loop.
- Not verified: live Godot launch, actual framerate, physical PC installation, creature rig quality, multiplayer, final custom assets, packaged EXE/APK.
- First real acceptance milestone: load in local Godot and complete `hub → wild → damage → capture → transform → arena → relaunch with save preserved` without errors.
